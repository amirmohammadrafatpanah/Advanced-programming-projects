#include "Perk.h"

Perk::Perk(Point p_pos, Point p_size, SDL_Texture *p_tex, int type)
    : Entity{p_pos, p_size, p_tex} {
    this->type = type;

}


int Perk::get_duration() const {
    return duration;
}

int Perk::get_timeout() const {
    return timeout;
}

void Perk::minus_duration() {
    duration--;
}

void Perk::minus_timeout() {
    timeout--;
}

int Perk::get_type() const {
    return type;
}




