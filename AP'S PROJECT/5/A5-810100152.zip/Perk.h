#pragma once

#include "Entity.hpp"

class Perk : public Entity {
public:
    Perk(Point p_pos, Point p_size, SDL_Texture* p_tex, int type);
    int get_type() const;
    int get_duration() const;
    int get_timeout() const;
    void minus_duration();
    void minus_timeout();

private:
    int type; // 0:speed - 1:armor
    int timeout = 100;
    int duration = 150;

};

