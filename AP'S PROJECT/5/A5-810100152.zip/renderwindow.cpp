#include <iostream>

#include "RenderWindow.hpp"

renderWindow::renderWindow(const char* p_title, int p_w, int p_h)
	:window(NULL), renderer(NULL)
{
	window = SDL_CreateWindow(p_title, SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, p_w, p_h, SDL_WINDOW_SHOWN);

	if (window == NULL) {
		std::cout << "Window failed to init. Error: " << SDL_GetError() << std::endl;
	}

	renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
    SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255);
}

void renderWindow::load_texture(const char* p_filePath)
{

	SDL_Texture* texture = NULL;
	texture = IMG_LoadTexture(renderer, p_filePath);
	texture_cache[p_filePath] = texture;
	if (texture == NULL)
		std::cout << "Failed to load texture. Error: " << SDL_GetError() << std::endl;

}

SDL_Texture *renderWindow::get_texture(const char *p_filePath) {
    return texture_cache[p_filePath];
}


void renderWindow::cleanup()
{
	SDL_DestroyWindow(window);
}

void renderWindow::clear()
{
	SDL_RenderClear(renderer);
}

void renderWindow::render(Entity& p_entity)
{
	SDL_Rect src; 
	src.x = p_entity.get_currentFrame().x;
	src.y = p_entity.get_currentFrame().y;
	src.w = p_entity.get_currentFrame().w;
	src.h = p_entity.get_currentFrame().h;

	SDL_Rect dst;
	dst.x = p_entity.get_pos().x ;
	dst.y = p_entity.get_pos().y ;
	dst.w = p_entity.get_currentFrame().w;
	dst.h = p_entity.get_currentFrame().h;

	SDL_RenderCopy(renderer, p_entity.get_tex(), &src, &dst);

}

void renderWindow::display()
{
    SDL_Delay(35);
	SDL_RenderPresent(renderer);
}

