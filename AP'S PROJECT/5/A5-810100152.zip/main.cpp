#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <iostream>
#include <vector>
#include <fstream>
#include <random>

#include "rsdl.hpp"
#include "Entity.hpp"
#include "RenderWindow.hpp"
#include "plane.h"
#include "Bullet.h"

int height;
int width;

void load_textures(renderWindow &window) {
    window.load_texture("res/bg.png");
    window.load_texture("res/plane.png");
    window.load_texture("res/bullet.png");
    window.load_texture("res/bullet2.png");
    window.load_texture("res/enemy.png");
    window.load_texture("res/moving_enemy.png");
    window.load_texture("res/enemy_bullet.png");
    window.load_texture("res/enemy_bullet2.png");
    window.load_texture("res/hostage.png");
    window.load_texture("res/explosion.png");
    window.load_texture("res/explosion2.png");
    window.load_texture("res/game_over.png");
    window.load_texture("res/victory.png");
    window.load_texture("res/armor.png");
    window.load_texture("res/speed.png");
}

int random_int() {
    static std::random_device rd;
    static std::mt19937 gen(rd());
    std::uniform_int_distribution<> dis(0, 100);
    return dis(gen);
}

std::vector<Entity> create_background(renderWindow &window, int n, int m) {
    std::vector<Entity> background;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            background.emplace_back(Point(j * 128, i * 128), Point(128, 128), window.get_texture("res/bg.png"));
        }
    }
    return background;
}


void fill_map(renderWindow win, std::vector<std::vector<std::string>> *maps, std::vector<std::vector<Plane>> *levels){
    // get map size
    int level_count = maps->size();
    int n = (*maps)[0].size();
    int m = (*maps)[0][0].size();

    // create map
    std::vector<Plane> temp;
    for (int k = 0; k < level_count; k++) {
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                switch ((*maps)[k][i][j]) {
                    case 'E':
                        temp.emplace_back(Point(((j-1) * 128)+ 162, i * 128), Point(59, 100),
                                          win.get_texture("res/enemy.png"), 2);
                        break;
                    case 'M':
                        temp.emplace_back(Point(((j-1) * 128)+ 142, i * 128), Point(100, 76),
                                          win.get_texture("res/moving_enemy.png"), 1);
                        break;
                    case 'S':
                        temp.emplace_back(Point(((j-1) * 128)+ 142, i * 128), Point(100, 76),
                                          win.get_texture("res/hostage.png"), 3);
                        break;
                    default:
                        break;
                }
            }
        }
        levels->push_back(temp);
        temp.clear();
    }
}

void read_map(const std::string& file_name, std::vector<std::vector<std::string>> *maps, int *levelCount) {

    // open file and read it
    std::ifstream file(file_name);
    std::string line;
    std::vector<std::string> map;
    std::getline(file, line);
    *levelCount = stoi(line);
    while (std::getline(file, line)) {
        if (line == "Easy" || line == "Medium" || line == "Hard") {
            maps->push_back(map);
            map.clear();
            continue;
        }
        map.push_back(line);
    }
    file.close();
}

bool is_winning(std::vector<Plane> *planes) {
    bool winning = true;
    for (auto & plane : *planes) {
        if (plane.get_type() == 1 || plane.get_type() == 2) {
            winning = false;
            break;
        }
    }

    return winning;
}

void win_message(renderWindow *win) {
    Entity message(Point((width-300)/2, (height-72)/2), Point(300, 72), win->get_texture("res/victory.png"));
    win->render(message);
    win->display();

}

void lose_message(renderWindow *win) {
    Entity message(Point((width-300)/2, (height-72)/2), Point(300, 72), win->get_texture("res/game_over.png"));
    win->render(message);
    win->display();

}


void explosion(renderWindow *win, Plane *p) {
    Entity explosion(p->get_pos(), Point(94, 100), win->get_texture("res/explosion.png"));

    explosion.set_cf(Point(explosion.get_currentFrame().x, explosion.get_currentFrame().h * p->get_ef() - 1));
    p->minus_ft();
    if(p->get_ft() == 0)
        p->minus_ef();
    win->render(explosion);
}

int main(int argc, char* args[]) {
	if (SDL_Init(SDL_INIT_VIDEO) > 0)
		std::cout << "SDL_Init HAS FAILED. SDL_ERROR: " << SDL_GetError() << std::endl;

	if (!(IMG_Init(IMG_INIT_PNG)))
		std::cout << "IMG_init has failed. Error: " << SDL_GetError() << std::endl;

    int level_count;
    std::vector<std::vector<std::string>> maps;
    std::vector<std::vector<Plane>> levels;
    std::vector<Entity> background;
    std::vector<Plane> planes;
    std::vector<Bullet> bullets;
    std::vector<Perk> perks;

    read_map(args[1], &maps, &level_count);
    height = maps[0].size() * 128;
    width = maps[0][0].size() * 128;

    renderWindow window("STAR WARS", width, height);
    load_textures(window);
    background = create_background(window, height/128, width/128);
    fill_map(window, &maps, &levels);
    bool is_finished = false;


    for (int n = 0; n < level_count && !is_finished; ++n) {

        Plane player = Plane(Point(0, 0), Point(100, 78), window.get_texture("res/plane.png"), 0);
        planes = levels[n];
        std::cout << "round #" << n+1 << ":" << '\n';

        bool game_running = true;
        bool won = false;

        SDL_Event event;
        bool shoot = false,
                left_pressed = false, right_pressed = false,
                up_pressed = false, down_pressed = false;
        int x_pos = (width-100)/2, y_pos = height - 114;


        while (game_running) {
            while (SDL_PollEvent(&event)) {
                switch (event.type) {
                    case SDL_QUIT:
                        is_finished = true;
                        game_running = false;
                        break;
                    case SDL_KEYDOWN:
                        switch (event.key.keysym.scancode) {
                            case SDL_SCANCODE_ESCAPE:
                                is_finished = true;
                                game_running = false;
                                break;
                            case SDL_SCANCODE_SPACE:
                                shoot = true;
                                break;
                            case SDL_SCANCODE_A:
                            case SDL_SCANCODE_LEFT:
                                left_pressed = true;
                                break;
                            case SDL_SCANCODE_D:
                            case SDL_SCANCODE_RIGHT:
                                right_pressed = true;
                                break;
                            case SDL_SCANCODE_W:
                            case SDL_SCANCODE_UP:
                                up_pressed = true;
                                break;
                            case SDL_SCANCODE_S:
                            case SDL_SCANCODE_DOWN:
                                down_pressed = true;
                                break;

                            default:
                                break;
                        }
                        break;
                    case SDL_KEYUP:
                        switch (event.key.keysym.scancode) {
                            case SDL_SCANCODE_SPACE:
                                shoot = false;
                                break;
                            case SDL_SCANCODE_A:
                            case SDL_SCANCODE_LEFT:
                                left_pressed = false;
                                break;
                            case SDL_SCANCODE_D:
                            case SDL_SCANCODE_RIGHT:
                                right_pressed = false;
                                break;
                            case SDL_SCANCODE_W:
                            case SDL_SCANCODE_UP:
                                up_pressed = false;
                                break;
                            case SDL_SCANCODE_S:
                            case SDL_SCANCODE_DOWN:
                                down_pressed = false;
                                break;
                            default:
                                break;
                        }
                        break;
                    default:
                        break;
                }
            }
            window.clear();

            x_pos += (right_pressed - left_pressed) * 14;
            y_pos += (down_pressed - up_pressed) * 14;

            if (shoot)
                player.shoot(&window, &bullets, height);

            player.setPose(Point(x_pos, y_pos));
            player.check_bound(width, height);
            player.check_bullet_collision(&bullets);
            player.check_plane_collision(&planes);
            player.check_perk_collision(&perks);
            player.consume_perk();

            // render background
            for (Entity e: background) {
                window.render(e);
            }

            // render planes
            window.render(player);
            if (player.is_dead()) {
                explosion(&window, &player);
                if (player.get_ef() < 0) {
                    std::cout << "Game Over\n";
                    is_finished = true;
                    game_running = false;
                }
            }

            //render perks
            for (std::vector<Perk>::size_type i = 0; i < perks.size(); ++i) {
                perks[i].minus_timeout();
                if (perks[i].get_timeout() == 0)
                    perks.erase(perks.begin() + i);

                window.render(perks[i]);
            }

            for (std::vector<Plane>::size_type i = 0; i < planes.size(); ++i) {
                planes[i].check_bullet_collision(&bullets);
                planes[i].shoot(&window, &bullets, height);
                window.render(planes[i]);

                if (planes[i].is_dead()) {
                    explosion(&window, &(planes[i]));
                    if (planes[i].get_ef() < 0) {
                        if (planes[i].get_type() == 3) {
                            std::cout << "Game Over\n";
                            is_finished = true;
                            game_running = false;
                        }

                        if (random_int() < 40) {// 40% chance
                            if (random_int() < 50) {
                                perks.emplace_back(planes[i].get_pos(), Point(64, 64),
                                                   window.get_texture("res/armor.png"), 1);
                            }
                            else {
                                perks.emplace_back(planes[i].get_pos(), Point(64, 64),
                                                   window.get_texture("res/speed.png"), 0);
                            }
                        }
                        planes.erase(planes.begin() + i);
                    }
                }
                planes[i].move(width);
            }

            // render bullets
            for (std::vector<Bullet>::size_type i = 0; i < bullets.size(); ++i) {
                if (bullets[i].is_out_of_bound() || bullets[i].get_destroyed())
                    bullets.erase(bullets.begin() + i);
                else {
                    bullets[i].move();
                    window.render(bullets[i]);
                }
            }
            if (is_winning(&planes)) {
                std::cout << "Victory\n";
                game_running = false;
                won = true;
            }

            window.display();
        }
        if (won)
            win_message(&window);
        else
            lose_message(&window);
        window.display();
        SDL_Delay(2500);
        bullets.clear();
        planes.clear();
        perks.clear();
    }


    window.cleanup();
	SDL_Quit();

	return 0;
}