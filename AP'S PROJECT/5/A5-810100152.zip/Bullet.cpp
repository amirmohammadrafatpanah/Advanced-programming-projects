#include "Bullet.h"

Bullet::Bullet(Point p_pos, Point p_size, SDL_Texture* p_tex, int height, bool direction)
        : Entity{ p_pos, p_size, p_tex}{
    this->direction = direction;
    this->height = height;
}


bool Bullet::get_destroyed() const {
    return destroyed;
}

bool Bullet::is_out_of_bound() {
    return get_pos().y < 1 || get_pos().y > height - 30;
}

void Bullet::move() {
    int new_y = get_pos().y + (direction ? -7 : 6);
    setPose({get_pos().x, new_y});
}

void Bullet::destroy() {
    destroyed = true;
}

bool Bullet::get_direction() const {
    return direction;
}
