#include "Entity.hpp"

Entity::Entity(Point p_pos, Point p_size, SDL_Texture* p_tex)
:pos(p_pos), tex(p_tex)
{
	currentFrame.x = 0;
	currentFrame.y = 0;
	currentFrame.w = p_size.x;
	currentFrame.h = p_size.y;
}

SDL_Texture* Entity::get_tex() {
	return tex;
}

SDL_Rect Entity::get_currentFrame() {
	return currentFrame;
}

void Entity::setPose(Point p_pos) {
    pos = p_pos;
}

void Entity::set_cf(Point p) {
    currentFrame.x = p.x;
    currentFrame.y = p.y;

}
