#include "plane.h"


Plane::Plane(Point p_pos, Point p_size, SDL_Texture* p_tex, int type)
    : Entity{ p_pos, p_size, p_tex} {
    this->type = type;
}

bool Plane::is_dead() {
    return dead;
}

Point Plane::check_bound(int width, int height) {
    if (pos.x <= 14) {
        pos.x = 14;
        direction = !direction;
    }
    if (pos.x >= width-114) {
        pos.x = width-114;
        direction = !direction;
    }
    if (pos.y <= 14)
        pos.y = 14;
    if (pos.y >= height-114)
        pos.y = height-114;

    return {pos.x, pos.y};
}

void Plane::move(int width) {
    if (type != 1)
        return;

    check_bound(width, 99999);

    if (direction)
        pos.x += 4;
    else
        pos.x -= 4;
}

void Plane::shoot(renderWindow *win, std::vector<Bullet > *bullets, int height) {
    if (!can_shoot())
        return;
    if (type == 0){
        Bullet b1(Point(pos.x + 22, pos.y), set_bullet_size(),
                  win->get_texture(set_bullet_texture()), height, true);
        Bullet b2(Point(pos.x + 70, pos.y), set_bullet_size(),
                  win->get_texture(set_bullet_texture()), height, true);
        bullets->push_back(b1);
        bullets->push_back(b2);
    }
    else {
        Bullet b(Point(pos.x + get_size().x / 2 - 2, pos.y + get_size().y), set_bullet_size(),
                 win->get_texture(set_bullet_texture()), height, false);
        bullets->push_back(b);
    }

}

bool Plane::can_shoot() {
    if (type == 3)
        return false;
    if (shoot_timeout == 0) {
        set_timeout();
        return true;
    }

    shoot_timeout--;
    return false;
}

void Plane::set_timeout() {
    switch (type) {
        case 0:
            shoot_timeout = has_speed_perk ? 5 : 11;
            break;
        case 1:
            shoot_timeout = 35;
            break;
        case 2:
            shoot_timeout = 55;
            break;
        default:
            break;
    }
}


const char * Plane::set_bullet_texture() const {
    switch (type) {
        case 0:
            return has_speed_perk ? "res/bullet2.png" : "res/bullet.png";
        case 1:
            return "res/enemy_bullet.png";
        case 2:
            return "res/enemy_bullet2.png";
        default:
            return "";
    }
}

Point Plane::set_bullet_size() const {
    switch (type) {
        case 0:
            return has_speed_perk ? Point(9, 20) : Point(11, 15);
        case 1:
            return {6, 15};
        case 2:
            return {6, 20};
        default:
            return {0, 0};
    }
}

void Plane::check_bullet_collision(std::vector<Bullet> *bullets) {
    for (auto & bullet : *bullets) {
        if (pos.x < bullet.get_pos().x && pos.x + get_size().x > bullet.get_pos().x + bullet.get_size().x &&
                pos.y < bullet.get_pos().y && pos.y + get_size().y > bullet.get_pos().y + bullet.get_size().y) {
            if (((type == 1 || type == 2 || type == 3) && !bullet.get_direction()) ||
                 (type == 0 && bullet.get_direction()))
                continue;
            bullet.destroy();
            if (!has_armor_perk) {
                dead = true;
            }
            has_armor_perk = false;
            break;
        }
    }
}

void Plane::check_plane_collision(std::vector<Plane> *planes) {
    for (auto & plane : *planes) {
        if (pos.x < plane.pos.x + 25 && pos.x + get_size().x > plane.pos.x + plane.get_size().x - 25 &&
                pos.y < plane.pos.y + 25 && pos.y + get_size().y > plane.pos.y + plane.get_size().y - 25) {
            dead = true;
            plane.set_dead();
            break;
        }
    }
}

void Plane::check_perk_collision(std::vector<Perk> *perks) {
    for (std::vector<Perk>::size_type i=0; i < perks->size(); i++) {
        if (pos.x < (*perks)[i].get_pos().x + 20 && pos.x + get_size().x > (*perks)[i].get_pos().x + (*perks)[i].get_size().x - 20 &&
            pos.y < (*perks)[i].get_pos().y + 20 && pos.y + get_size().y > (*perks)[i].get_pos().y + (*perks)[i].get_size().y - 20) {
            if ((*perks)[i].get_type() == 0) {
                has_speed_perk = true;
                speed = (*perks)[i];
                perks->erase(perks->begin()+i);
            }
            if ((*perks)[i].get_type() == 1) {
                has_armor_perk = true;
                armor = (*perks)[i];
                perks->erase(perks->begin()+i);
            }
            break;
        }
    }

}

void Plane::set_dead() {
    dead = true;

}

void Plane::minus_ft() {
    frame_time--;
    if (frame_time < 0)
        frame_time = 2;
}

void Plane::minus_ef() {
    explode_frames--;
}

int Plane::get_ef() const {
    return explode_frames;
}

int Plane::get_ft() const {
    return frame_time;
}

int Plane::get_type() const {
    return type;
}

void Plane::consume_perk() {
    if (has_armor_perk) {
        armor.minus_duration();
        if (armor.get_duration() == 0)
            has_armor_perk = false;
    }

    if (has_speed_perk) {
        speed.minus_duration();
        if (speed.get_duration() == 0)
            has_speed_perk = false;
    }
}





