#pragma once
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include "rsdl.hpp"


class Entity {
public:
	Entity(Point p_pos, Point p_size, SDL_Texture* p_tex);
	Point& get_pos() {
		return pos;
	}
	Point get_size() {
	    return {currentFrame.w, currentFrame.h};
	}
	SDL_Texture* get_tex();
	SDL_Rect get_currentFrame();
	void setPose(Point p_pos);
	void set_cf(Point p);

protected:
	Point pos;

private:
	SDL_Rect currentFrame;
	SDL_Texture* tex;

};