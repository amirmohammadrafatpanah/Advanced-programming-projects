#pragma once

#include <vector>
#include "Entity.hpp"



class Bullet : public Entity {
public:
    Bullet(Point p_pos, Point p_size, SDL_Texture* p_tex, int height, bool direction);
    void destroy();
    bool get_destroyed() const;
    bool is_out_of_bound();
    bool get_direction() const;
    void move();

private:
    int height;
    bool destroyed = false;
    bool direction; // false:down - true:up

};
