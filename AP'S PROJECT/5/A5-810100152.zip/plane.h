#pragma once

#include <vector>
#include "Entity.hpp"
#include "RenderWindow.hpp"
#include "Bullet.h"
#include "Perk.h"


class Plane : public Entity  {
public:
    Plane(Point p_pos, Point p_size, SDL_Texture* p_tex, int type);
    bool is_dead();
    void set_dead();
    void move(int width);
    bool can_shoot();
    const char * set_bullet_texture() const;
    Point set_bullet_size() const;
    void shoot(renderWindow *win, std::vector<Bullet> *bullets, int height);
    void check_bullet_collision(std::vector<Bullet> *bullets);
    void check_plane_collision(std::vector<Plane> * planes);
    void check_perk_collision(std::vector<Perk> *perks);
    Point check_bound(int width, int height);
    void minus_ft();
    int get_ft() const;
    void minus_ef();
    int get_ef() const;
    int get_type() const;
    void consume_perk();


private:
    void set_timeout();
    int shoot_timeout = 0;
    int type; // -> 0:user - 1:simple - 2:moving - 3:hostage
    bool direction = false; // false:right - true: left
    bool dead = false;
    bool has_speed_perk = false;
    bool has_armor_perk = false;
    Perk speed = Perk(Point(0, 0), Point(64, 64), nullptr, 0);
    Perk armor = Perk(Point(0, 0), Point(64, 64), nullptr, 1);
    int explode_frames = 4;
    int frame_time = 2;

};


