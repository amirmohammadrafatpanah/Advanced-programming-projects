#include "Commands/FinishCommand.hpp"
#include "MemoryManager.hpp"

std::map<std::string, std::string>
FinishCommand::parseArgs(std::vector<std::string> args) {
  std::map<std::string, std::string> tempData;

  for (std::size_t i = 0; i < args.size(); i += 2) {
    tempData[args[i]] = args[i + 1];
  }

  return tempData;
}

FinishCommand::FinishCommand(std::vector<std::string> args,
                             const std::string &method, MemoryManager *memory) {
  auto parsedArgs = this->parseArgs(args);
  this->method = method;

  this->username = parsedArgs["username"];
  this->id =
      std::stoi(parsedArgs["id"].empty() ? "" : parsedArgs["id"].c_str());

  this->memory = memory;
}

std::string FinishCommand::getUsername() { return this->username; }
int FinishCommand::getID() { return this->id; }

void FinishCommand::execute() {
  if (this->method != "POST") {
    std::cerr << "Bad Request" << std::endl;
    return;
  }

  if (this->username.empty() || this->id <= 0) {
    std::cerr << "Bad Request" << std::endl;
    return;
  }

  if (this->memory->getUserRole(this->username) != "driver") {
    std::cerr << "Permission Denied" << std::endl;
    return;
  }

  if (!this->memory->isTripExists(this->id)) {
    std::cerr << "Not Found" << std::endl;
    return;
  }

  if (this->memory->isTripBelongsToDriver(this->id, this->username))

    this->memory->finishTrip(this->id);

  std::cout << "OK" << std::endl;
}
