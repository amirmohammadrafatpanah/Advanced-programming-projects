#ifndef __TRIPS_COMMAND__
#define __TRIPS_COMMAND__

#include "LocationManager.hpp"
#include "MemoryManager.hpp"
#include <iostream>

class TripsCommand {
  std::string method;
  std::string username;
  std::string origin;
  std::string destination;
  int id;
  MemoryManager *memory;
  LocationManager *locations;

public:
  TripsCommand(std::vector<std::string> args, const std::string &requestMethod,
               LocationManager *locations, MemoryManager *memory);

  std::string getUsername();
  std::string getOrigin();
  std::string getDestination();
  int getID();

  void execute();

private:
  std::map<std::string, std::string> parseArgs(std::vector<std::string> args);
};

#endif