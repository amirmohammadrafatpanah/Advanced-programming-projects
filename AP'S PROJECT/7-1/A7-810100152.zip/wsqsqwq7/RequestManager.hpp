#ifndef __REQUEST_MANAGER__
#define __REQUEST_MANAGER__

#include "LocationManager.hpp"
#include "MemoryManager.hpp"
#include <iostream>
#include <vector>

class RequestManager {
  std::string command;
  std::vector<std::string> commandParts;
  MemoryManager *memory;
  LocationManager *locations;

public:
  RequestManager(const std::string &command, LocationManager *locations,
                 MemoryManager *memory);

  std::string getMethod();
  std::string getCommandName();
  void parseCommand();

private:
  std::vector<std::string> splitCommand();
};

#endif