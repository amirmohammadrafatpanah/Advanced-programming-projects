#include "Commands/SignupCommand.hpp"
#include "MemoryManager.hpp"
#include <map>
#include <vector>

SignupCommand::SignupCommand(std::vector<std::string> args,
                             const std::string &requestMethod,
                             MemoryManager *memory) {
  auto parsedArgs = this->parseArgs(args);
  this->method = requestMethod;

  this->username = parsedArgs["username"];
  this->role = parsedArgs["role"];

  this->memory = memory;
}

std::map<std::string, std::string>
SignupCommand::parseArgs(std::vector<std::string> args) {
  std::map<std::string, std::string> tempData;

  for (std::size_t i = 0; i < args.size(); i += 2) {
    tempData[args[i]] = args[i + 1];
  }

  return tempData;
}

std::string SignupCommand::getUsername() { return this->username; }

std::string SignupCommand::getRole() { return this->role; }

void SignupCommand::execute() {
  if (this->method != "POST") {
    std::cerr << "Bad Request" << std::endl;
    return;
  }

  if (this->username == "" || this->role == "") {
    std::cerr << "Bad Request" << std::endl;
    return;
  }

  if (this->memory->isUsernameDuplicate(this->username)) {
    std::cerr << "Bad Request" << std::endl;
    return;
  }

  if (this->role != "driver" && this->role != "passenger") {
    std::cerr << "Bad Request" << std::endl;
    return;
  }

  this->memory->addUser(this->username, this->role);

  std::cout << "OK" << std::endl;
}