#include "RequestManager.hpp"
#include "Commands/AcceptCommand.hpp"
#include "Commands/FinishCommand.hpp"
#include "Commands/SignupCommand.hpp"
#include "Commands/TripsCommand.hpp"
#include "LocationManager.hpp"
#include <iostream>
#include <sstream>
#include <vector>

RequestManager::RequestManager(const std::string &command,
                               LocationManager *locations,
                               MemoryManager *memory) {
  this->command = command;
  this->commandParts = this->splitCommand();
  this->memory = memory;
  this->locations = locations;
}

std::vector<std::string> RequestManager::splitCommand() {
  std::vector<std::string> tempCommandParts;
  std::string tempCommandPart;
  std::stringstream tempCommand(this->command);

  while (std::getline(tempCommand, tempCommandPart, ' ')) {
    tempCommandParts.push_back(tempCommandPart);
  }

  if (tempCommandParts.size() < 5) {
    std::cerr << "Bad Request" << std::endl;
    exit(EXIT_FAILURE);
  }

  return tempCommandParts;
}

std::string RequestManager::getMethod() {

  std::vector<std::string> methods{"GET", "POST", "DELETE"};

  for (auto method : methods) {
    if (this->commandParts[0] == method)
      return method;
  }

  std::cerr << "Bad Request" << std::endl;
  return "";
}

std::string RequestManager::getCommandName() {
  std::vector<std::string> commandTypes{"signup", "trips", "accept", "finish"};

  for (auto commandType : commandTypes) {
    if (this->commandParts[1] == commandType)
      return commandType;
  }

  std::cerr << "Bad Request" << std::endl;
  return "";
}

void RequestManager::parseCommand() {
  std::string command = this->getCommandName();
  std::vector<std::string> args;

  for (std::size_t i = 3; i < this->commandParts.size(); i++) {
    args.push_back(this->commandParts[i]);
  }

  if (command == "signup") {
    SignupCommand signupCommand(args, this->getMethod(), this->memory);

    signupCommand.execute();
  } else if (command == "trips") {
    TripsCommand tripsCommand(args, this->getMethod(), this->locations,
                              this->memory);

    tripsCommand.execute();
  } else if (command == "accept") {
    AcceptCommand acceptCommand(args, this->getMethod(), this->memory);

    acceptCommand.execute();
  } else if (command == "finish") {
    FinishCommand finishCommand(args, this->getMethod(), this->memory);

    finishCommand.execute();
  }
}