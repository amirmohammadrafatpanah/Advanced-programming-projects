#include "Commands/AcceptCommand.hpp"
#include <iostream>

std::map<std::string, std::string>
AcceptCommand::parseArgs(std::vector<std::string> args) {
  std::map<std::string, std::string> tempData;

  for (std::size_t i = 0; i < args.size(); i += 2) {
    tempData[args[i]] = args[i + 1];
  }

  return tempData;
}

AcceptCommand::AcceptCommand(std::vector<std::string> args,
                             const std::string &method, MemoryManager *memory) {
  auto parsedArgs = this->parseArgs(args);
  this->method = method;

  this->username = parsedArgs["username"];
  this->id =
      std::stoi(parsedArgs["id"].empty() ? "0" : parsedArgs["id"].c_str());

  this->memory = memory;
}

std::string AcceptCommand::getUsername() { return this->username; }
int AcceptCommand::getID() { return this->id; }

void AcceptCommand::execute() {
  if (this->method != "POST") {
    std::cerr << "Bad Request" << std::endl;
    return;
  }

  if (this->username.empty() || this->id <= 0) {
    std::cerr << "Bad Request" << std::endl;
    return;
  }

  if (this->memory->getUserRole(this->username) != "driver") {
    std::cerr << "Permission Denied" << std::endl;
    return;
  }

  if (!this->memory->isTripExists(this->id)) {
    std::cerr << "Not Found" << std::endl;
    return;
  }

  if (this->memory->isDriverOnTrip(this->username)) {
    std::cerr << "Bad Request" << std::endl;
    return;
  }

  this->memory->acceptTrip(this->id, this->username);

  std::cout << "OK" << std::endl;
}