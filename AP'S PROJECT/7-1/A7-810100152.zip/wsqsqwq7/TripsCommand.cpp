#include "Commands/TripsCommand.hpp"
#include "LocationManager.hpp"
#include "MemoryManager.hpp"
#include <sstream>

std::map<std::string, std::string>
TripsCommand::parseArgs(std::vector<std::string> args) {
  std::map<std::string, std::string> tempData;

  for (std::size_t i = 0; i < args.size(); i += 2) {
    tempData[args[i]] = args[i + 1];
  }

  return tempData;
}

TripsCommand::TripsCommand(std::vector<std::string> args,
                           const std::string &method,
                           LocationManager *locations, MemoryManager *memory) {
  auto parsedArgs = this->parseArgs(args);
  this->method = method;

  this->username = parsedArgs["username"];
  this->origin = parsedArgs["origin"];
  this->destination = parsedArgs["destination"];
  this->id = std::stoi(parsedArgs["id"].size() > 0 ? parsedArgs["id"] : "0");

  this->memory = memory;
  this->locations = locations;
}

std::string TripsCommand::getUsername() { return this->username; }
std::string TripsCommand::getOrigin() { return this->origin; }
std::string TripsCommand::getDestination() { return this->destination; }
int TripsCommand::getID() { return this->id; }

void TripsCommand::execute() {
  if (this->username == "") {
    std::cerr << "Bad Request" << std::endl;
    return;
  }

  if (this->method == "POST") {
    if (this->origin == "" || this->destination == "") {
      std::cerr << "Bad Request" << std::endl;
      return;
    }

    if (!this->memory->isUserExists(username)) {
      std::cerr << "Not Found" << std::endl;
      return;
    }

    if (!this->locations->isLocationExists(this->origin) ||
        !this->locations->isLocationExists(this->destination)) {
      std::cerr << "Not Found" << std::endl;
      return;
    }

    if (this->memory->getUserRole(this->username) != "passenger") {
      std::cerr << "Permission Denied" << std::endl;
      return;
    }

    if (this->memory->isUserOnTrip(this->username)) {
      std::cerr << "Bad Request" << std::endl;
      return;
    }

    std::cout << this->memory->addTrip(this->username, this->origin,
                                       this->destination)
              << std::endl;

  } else if (this->method == "GET") {
    if (this->memory->getUserRole(this->username) != "driver") {
      std::cerr << "Permission Denied" << std::endl;
      return;
    }

    if (!this->id) {

      auto trips = this->memory->getTrips();

      if (trips.size() == 0) {
        std::cerr << "Empty" << std::endl;
        return;
      }

      for (auto trip : trips) {
        auto tripID = trip.first;
        auto tripInfo = trip.second.first;
        auto tripStatus = trip.second.second;
        std::string parsedString;
        std::stringstream tempParsedString;

        if (tripStatus.empty())
          continue;

        std::cout << tripID << " ";
        for (auto info : tripInfo) {
          std::cout << info << " ";
        }
        std::cout << tripStatus << std::endl;
      }
    } else {
      auto trip = this->memory->getTrip(this->id);

      auto tripID = trip.first;
      auto tripInfo = trip.second.first;
      auto tripStatus = trip.second.second;
      std::string parsedString;
      std::stringstream tempParsedString;

      if (!!tripStatus.empty()) {
        std::cerr << "Not Found" << std::endl;
        return;
      }

      std::cout << tripID << " ";
      for (auto info : tripInfo) {
        std::cout << info << " ";
      }
      std::cout << tripStatus << std::endl;
    }

  } else if (this->method == "DELETE") {
    if (this->memory->getUserRole(this->username) != "passenger") {
      std::cerr << "Permission Denied" << std::endl;
      return;
    }

    if (this->id <= 0) {
      std::cerr << "Bad Request" << std::endl;
      return;
    }

    if (!this->memory->isTripExists(this->id)) {
      std::cout << "Not Found" << std::endl;
      return;
    }
    if (!this->memory->isTripBelongsToUser(this->id, this->username)) {
      std::cerr << "Permission Denied" << std::endl;
      return;
    }

    if (this->memory->getTripStatus(this->id) == "canceled") {
      std::cerr << "Not Found" << std::endl;
      return;
    }

    if (!this->memory->isTripCancelable(this->id)) {
      std::cerr << "Bad Request" << std::endl;
      return;
    }

    this->memory->cancelTrip(this->id);

    std::cout << "OK" << std::endl;
  }
}