#ifndef __ERROR_MANAGER__
#define __ERROR_MANAGER__

#endif