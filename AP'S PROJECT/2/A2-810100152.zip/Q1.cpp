#include<iostream>
#include<vector>
#include<string>
using namespace std;
string input_variable = "0";
string stock = "";
void convorter( int i) {
	if (input_variable[i] == '0')
		stock += "01";
	else if (input_variable[i] == '1')
		stock += "10";
	if (i + 1 < input_variable.length())
		convorter(i + 1);
}
int main() {
	int n,k;
	cin >> n >> k;
	for (int j = 0; j < n; j++) {
		convorter(0);
		input_variable = stock;
		stock = "";
	}
	cout << input_variable[k-1];
}	