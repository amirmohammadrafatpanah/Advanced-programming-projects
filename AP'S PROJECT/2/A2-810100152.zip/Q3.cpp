#include<iostream>
#include<string>
#include<vector>
#include<algorithm>

using namespace std;

const char rock = '#', bamboo = '*', normal_path = '.';
vector<string> land;
int n, m;
vector<unsigned int> result;

void get_input() {
    string input;
    while (cin >> input) {
        land.push_back(input);
    }
    n = input.length();
    m = land.size();
}

bool ok(int row, int column) {
    if (row >= 0 && column >= 0 && row < n && column < m) {
        return true;
    }
    return false;
}

bool superOk(int row, int column, vector <vector< bool >> is_seen) {
    if (ok(row, column) && land[row][column] != rock && is_seen[row][column] == false) {
        return true;
    }
    return false;
}

int add_row(int row, int direction) {
    if (direction % 2 == 1)return row;
    else if (direction == 2)return row + 1;
    return row - 1;
}
//0 = up , 1 = right , 2 = down , 3 = left
int add_column(int column, int direction) {
    if (direction % 2 == 0)return column;
    else if (direction == 1)return column + 1;
    return column - 1;
}

void backtracking(int row, int column, int direction, int len, vector <vector< bool >> is_seen) {
    is_seen[row][column] = true;
    int new_row = add_row(row, direction), new_column = add_column(column, direction);
    cout << row << column << endl;
    if (ok(new_row, new_column)) {


        if (land[new_row][new_column] == bamboo) {
             result.push_back(len + 1);
        }
        else if (land[new_row][new_column] == normal_path) {
             backtracking(new_row, new_column, direction, len + 1, is_seen);
            
        }
        else if (direction % 2 == 1) {        
            if (superOk(row, column - 1, is_seen)) {
                backtracking(row, column - 1, 0, len + 1, is_seen);
            }
            if (superOk(row, column + 1, is_seen)) {
                backtracking(row, column + 1, 2, len + 1, is_seen);               
            }
        }
        else {
            if (superOk(row + 1, column, is_seen)) {
                backtracking(row + 1, column, 1, len + 1, is_seen);          
            }
            if (superOk(row - 1, column, is_seen)) {
                 backtracking(row - 1, column, 3, len + 1, is_seen);            
            }
        }
    }
    else {
        if (new_row < 0) {
     
            if (superOk(0, column + 1, is_seen)) {
                backtracking(0, column + 1, 2, len + 1, is_seen);
            }
            if (superOk(0, column - 1, is_seen)) {
                backtracking(0, column - 1, 0, len + 1, is_seen);
            }
        }
        else if (new_column < 0) {
            if (superOk(row + 1, 0, is_seen)) {
                backtracking(row + 1, 0, 1, len + 1, is_seen);
            }
            if (superOk(row - 1, 0, is_seen)) {
                backtracking(row - 1, 0, 3, len + 1, is_seen);
            }
        }
        else if (!(new_row < n)) {
            if (superOk(n - 1, column + 1, is_seen)) {
                backtracking(n - 1, column + 1, 2, len + 1, is_seen);
            }
            if (superOk(n - 1, column - 1, is_seen)) {
                backtracking(n - 1, column - 1, 0, len + 1, is_seen);
            }
        }
        else if (!(new_column < m)) {
            if (superOk(row + 1, m - 1, is_seen)) {
                backtracking(row + 1, m - 1, 1, len + 1, is_seen);
            }
            if (superOk(row - 1, m - 1, is_seen))backtracking(row - 1, m - 1, 3, len + 1, is_seen);
        }
    }
}
int main() {
    get_input();
    vector <vector< bool >> is_seen(n, vector<bool>(m, false));
    backtracking(0, 0, 2, 0, is_seen);
    if (result.size() == 0)
    cout << *min_element(result.begin(), result.end());
}
