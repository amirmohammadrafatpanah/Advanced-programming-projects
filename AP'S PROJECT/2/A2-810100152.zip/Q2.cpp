#include<iostream>
#include<string>

using namespace std;

string mix;
bool is_sub, is_seq;

void check_words(string str, int i, int j) {
    if (j >= str.length()) {
        is_sub = true;
    }
    else if (i >= mix.length()) {
        is_seq = true;
    }
    else if (str[j] == mix[i]) {
        mix.erase(i, 1);
        check_words(str, i, j + 1);
    }
    else
        check_words(str, i + 1, j);
}
int main() {
    string first_word, second_word;
    cin >> first_word >> second_word >> mix;
    string temp = mix;
    check_words(first_word, 0, 0);
    if (is_sub && mix == second_word) {
        cout << "Interleaving";
        return 0;
    }
    mix = temp;
    check_words(second_word, 0, 0);
    if (is_sub && mix == first_word) {
        cout << "Interleaving";
        return 0;
    }
    cout << "Not Interleaving";
    return 0;
}