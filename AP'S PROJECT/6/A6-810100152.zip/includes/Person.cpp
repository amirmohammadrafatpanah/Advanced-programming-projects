#include "./Person.hpp"
#include <algorithm>
#include <cstdlib>

Person::Person(string name, int permitted_for_borrow) {
  this->name = name;
  this->permitted_for_borrow = permitted_for_borrow;
}

bool Person::is_permitted_for_borrow() {
  return this->permitted_for_borrow > 0;
}

string Person::get_name() { return this->name; }

void Person::borrow(string document_name, int time) {
  if (this->permitted_for_borrow == 0) {
    cout << "Maximum number of allowed borrows exceeded" << endl;
    exit(EXIT_SUCCESS);
  }

  for (int i = 0; i < this->borrowed_documents.size(); i++) {
    if (this->borrowed_documents.at(i).document_title == document_name) {
      cout << "You borrowed this document already" << endl;
      exit(EXIT_SUCCESS);
    }
  }

  BorrowingDocument borrowing_document;
  borrowing_document.document_title = document_name;
  borrowing_document.is_returned = false;
  borrowing_document.penalty = 0;
  borrowing_document.deadline = time;

  this->borrowed_documents.push_back(borrowing_document);
  this->permitted_for_borrow--;
}

void Person::return_document(string document, int time) {
  for (int i = 0; i < this->borrowed_documents.size(); i++) {
    if (this->borrowed_documents.at(i).document_title == document) {
      this->borrowed_documents.at(i).is_returned = true;
      this->borrowed_documents.at(i).penalty =
          this->borrowed_documents.at(i).deadline - time;
      return;
    }
  }

  cout << "You have not borrowed this document" << endl;
  exit(EXIT_SUCCESS);
}

void Person::expand(string document_title, int time, int shelf_time) {

  for (int i = 0; i < this->borrowed_documents.size(); i++) {
    if (this->borrowed_documents.at(i).document_title == document_title) {
      if (this->borrowed_documents.at(i).permitted_for_extend == 0) {
        cout << "You can't renew a document more than two times" << endl;
        exit(EXIT_SUCCESS);
      }

      if (time == this->borrowed_documents.at(i).deadline) {
        cout << "You can't extend and borrow a document on the same day"
             << endl;
        exit(EXIT_SUCCESS);

      } else if (time > this->borrowed_documents.at(i).deadline) {
        cout << "You can't renew a document after receiving a penalty" << endl;
        exit(EXIT_SUCCESS);
      }
      this->borrowed_documents.at(i).deadline += shelf_time;
      this->borrowed_documents.at(i).permitted_for_extend--;
    }
  }
}

int Person::get_penalty(int time) {
  int penalty = 0;

  for (int i = 0; i < this->borrowed_documents.size(); i++) {
    penalty += this->borrowed_documents.at(i).penalty;
  }

  return penalty * 10000;
}