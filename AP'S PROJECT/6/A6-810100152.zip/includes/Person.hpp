#ifndef __PERSON__
#define __PERSON__

#include "Document.hpp"
#include <iostream>
#include <vector>

using namespace std;

struct BorrowingDocument {
  string document_title;
  int deadline;
  bool is_returned;
  int penalty;
  int permitted_for_extend = 2;
};

class Person {
public:
  Person(string name, int permitted_for_borrow);
  bool is_permitted_for_borrow();
  string get_name();
  void borrow(string document_name, int time);
  void expand(string document_title, int time, int shelf_time);
  void return_document(string document_name, int time);
  int get_penalty(int time);

private:
  string name;
  int permitted_for_borrow;
  vector<BorrowingDocument> borrowed_documents;
};

#endif