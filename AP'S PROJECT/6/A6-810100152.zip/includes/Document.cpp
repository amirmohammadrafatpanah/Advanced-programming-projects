#include "./Document.hpp"
#include <cstdlib>
#include <iostream>

Document::Document(string title, int inventory, int shelf_time) {
  this->title = title;
  this->inventory = inventory;
  this->shelf_time = shelf_time;
}

void Document::set_delivery_deadline(int time) {
  this->delivery_deadline = time;
}

string Document::get_title() { return this->title; }

void Document::borrow() {
  if (this->inventory == 0) {
    cout << "This document does not exist" << endl;
    exit(EXIT_SUCCESS);
  }

  this->inventory--;
}

void Document::return_document() { this->inventory++; }

int Document::get_shelf_time() { return this->shelf_time; }