#include "./Reference.hpp"
#include <cstdlib>

Reference::Reference(string title, int copies) : Document(title, copies, 5) {}

void Reference::renew() {
  cout << "You can't renew magazines" << endl;
  exit(EXIT_SUCCESS);
}