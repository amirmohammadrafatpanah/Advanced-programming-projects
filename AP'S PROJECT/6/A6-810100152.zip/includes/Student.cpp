#include "./Student.hpp"
#include <iostream>

using namespace std;

Student::Student(string id, string name) : Person(name, 2) { this->id = id; }

string Student::get_id() { return this->id; }
