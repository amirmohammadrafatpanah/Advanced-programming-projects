#ifndef __BOOK__
#define __BOOK__

#include "Document.hpp"
#include <iostream>

using namespace std;

class Book : public Document {
public:
  Book(string title, int copies);
  void renew();
};

#endif
