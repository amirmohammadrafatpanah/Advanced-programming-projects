#ifndef __PROFESSOR__
#define __PROFESSOR__

#include "Person.hpp"
#include <iostream>

using namespace std;

class Professor : public Person {
public:
  Professor(string name);
};

#endif