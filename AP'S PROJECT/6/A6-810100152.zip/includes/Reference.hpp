#ifndef __REFERENCE__
#define __REFERENCE__

#include "Document.hpp"
#include <iostream>

using namespace std;

class Reference : public Document {
public:
  Reference(string title, int copies);
  void renew();
};

#endif