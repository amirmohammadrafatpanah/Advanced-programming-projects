#include "./Library.hpp"
#include "Book.hpp"
#include "Document.hpp"
#include "Magazine.hpp"
#include "Professor.hpp"
#include "Reference.hpp"
#include "Student.hpp"
#include <cstdlib>
#include <iostream>

using namespace std;

void Library::add_student_member(string student_id, string student_name) {
  if (student_id == "" || student_name == "") {
    cout << "Empty field" << endl;
    exit(EXIT_SUCCESS);
  }

  for (int i = 0; i < this->users.size(); i++) {
    if (this->users.at(i).get_name() == student_name) {
      cout << "Name already exitsts" << endl;
      exit(EXIT_SUCCESS);
    }
  }

  Student new_student_member(student_id, student_name);

  this->users.push_back(new_student_member);
}

void Library::add_prof_member(string prof_name) {
  for (int i = 0; i < this->users.size(); i++) {
    if (this->users.at(i).get_name() == prof_name) {
      cout << "Name already exitsts" << endl;
      exit(EXIT_SUCCESS);
    }
  }

  Professor new_professor_member(prof_name);

  this->users.push_back(new_professor_member);
}

void Library::add_book(string book_title, int copies) {

  for (int i = 0; i < this->documents.size(); i++) {
    if (this->documents.at(i).get_title() == book_title) {
      cout << "A document with the specified name already exists" << endl;
      exit(EXIT_SUCCESS);
    }
  }

  Book new_book(book_title, copies);

  this->documents.push_back(new_book);
}

void Library::add_magazine(string magazine_title, int year, int number,
                           int copies) {
  Magazine new_magazine(magazine_title, year, number, copies);

  this->documents.push_back(new_magazine);
}

void Library::add_reference(string reference_title, int copies) {
  Reference new_reference(reference_title, copies);

  this->documents.push_back(new_reference);
}

void Library::borrow(string member_name, string document_title) {

  for (int i = 0; i < this->documents.size(); i++) {
    if (this->documents.at(i).get_title() == document_title) {
      for (int j = 0; j < this->users.size(); j++) {
        if (this->users.at(j).get_name() == member_name) {
          this->users.at(j).borrow(document_title,
                                   this->time +
                                       this->documents.at(i).get_shelf_time());
          this->documents.at(i).borrow();
          return;
        }
      }
    }
  }

  cout << "This document does not exist" << endl;
  exit(EXIT_SUCCESS);
}

void Library::expand(string member_name, string document_title) {
  for (int i = 0; i < this->documents.size(); i++) {
    if (this->documents.at(i).get_title() == document_title) {
      for (int j = 0; j < this->users.size(); j++) {
        if (this->users.at(j).get_name() == member_name) {
          this->documents.at(i).renew();
          this->users.at(j).expand(document_title, this->time,
                                   this->documents.at(i).get_shelf_time());
          return;
        }
      }
    }
  }
}

void Library::return_document(string member_name, string document_title) {
  for (int i = 0; i < this->documents.size(); i++) {
    if (this->documents.at(i).get_title() == document_title) {
      for (int j = 0; j < this->users.size(); j++) {
        if (this->users.at(j).get_name() == member_name) {
          this->users.at(j).return_document(document_title, this->time);
          this->documents.at(i).return_document();
          return;
        }
      }
    }
  }
}

int Library::get_total_penalty(string member_name) {
  int penalty = 0;

  for (int i = 0; i < this->users.size(); i++) {
    if (this->users.at(i).get_name() == member_name) {
      penalty = this->users.at(i).get_penalty(this->time);
    }
  }

  return penalty;
}

vector<string> Library::available_titles() {
  vector<string> titles;

  for (int i = 0; i < this->documents.size(); i++) {
    titles.push_back(this->documents.at(i).get_title());
  }

  return titles;
}

void Library::time_pass(int days) {
  if (days < 0) {
    cout << "Invalid day" << endl;
    exit(EXIT_SUCCESS);
  }
  this->time += days;
}
