#include "./Book.hpp"
#include <iostream>

using namespace std;

Book::Book(string title, int copies) : Document(title, copies, 10) {}

void Book::renew() {
  if (this->allowed_renew_times == 0) {
    cout << "You can't renew a document more than two times" << endl;
    exit(EXIT_SUCCESS);
  }

  this->allowed_renew_times--;
}
