#ifndef __LIBRARY__
#define __LIBRARY__

#include "Document.hpp"
#include "Person.hpp"
#include <iostream>
#include <vector>

using namespace std;

class Library {
public:
  void add_student_member(string student_id, string student_name);
  void add_prof_member(string prof_name);
  void add_book(string book_title, int copies);
  void add_magazine(string magazine_title, int year, int number, int copies);
  void add_reference(string reference_title, int copies);
  void borrow(string member_name, string document_title);
  void expand(string member_name, string document_title);
  void return_document(string member_name, string document_title);
  void time_pass(int days);
  int get_total_penalty(string member_name);
  vector<string> available_titles();

private:
  vector<Person> users;
  vector<Document> documents;
  int time = 0;
};

#endif
