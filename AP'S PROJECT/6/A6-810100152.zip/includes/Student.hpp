#ifndef __STUDENT__
#define __STUDENT__

#include "./Person.hpp"
#include <iostream>

using namespace std;

class Student : public Person {
public:
  Student(string id, string name);

  string get_id();

private:
  string id;
};

#endif