#include "./Professor.hpp"
#include <iostream>

using namespace std;

Professor::Professor(string name) : Person(name, 5) {}