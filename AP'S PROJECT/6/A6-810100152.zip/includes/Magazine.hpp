#ifndef __MAGAZINE__
#define __MAGAZINE__

#include "./Document.hpp"

class Magazine : public Document {
public:
  Magazine(string title, int year, int number, int copies);
  void renew();

private:
  int year;
  int number;
};

#endif