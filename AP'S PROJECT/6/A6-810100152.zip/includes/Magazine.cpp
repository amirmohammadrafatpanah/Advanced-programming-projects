#include "Magazine.hpp"
#include <cstdlib>
#include <iostream>

using namespace std;

Magazine::Magazine(string title, int year, int number, int copies)
    : Document(title, copies, 2) {
  if (number <= 0) {
    cout << "Invalid number" << endl;
    exit(EXIT_SUCCESS);
  } else if (year <= 0) {
    cout << "Invalid year" << endl;
    exit(EXIT_SUCCESS);
  }
}

void Magazine::renew() {
  if (this->allowed_renew_times == 0) {
    cout << "You can't renew a document more than two times" << endl;
    exit(EXIT_SUCCESS);
  }

  this->allowed_renew_times--;
}