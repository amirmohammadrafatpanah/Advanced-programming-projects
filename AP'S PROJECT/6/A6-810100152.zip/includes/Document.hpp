#ifndef __DOCUMENT__
#define __DOCUMENT__

#include <iostream>

using namespace std;

class Document {
public:
  Document(string title, int inventory, int shelft_time);
  void renew() { return; };
  void borrow();
  void return_document();
  string get_title();
  int get_shelf_time();

private:
  string title;
  int delivery_deadline;
  int shelf_time;

protected:
  int inventory;
  int allowed_renew_times = 2;

  void set_delivery_deadline(int time);
};

#endif