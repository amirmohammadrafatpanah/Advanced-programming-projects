#include "includes/Library.hpp"
#include <iostream>
#include <vector>

using namespace std;

int main() {

  Library library{};

  library.add_student_member("000001", "iman");

  library.add_book("book1", 2);
  library.add_magazine("mag1", 1400, 112, 10);
  library.add_reference("ref1", 1);

  library.borrow("iman", "book1");

  vector<string> titles = library.available_titles();

  for (int i = 0; i < titles.size(); i++)
    cout << titles[i] << endl;

  library.time_pass(22);

  library.return_document("iman", "mag1");

  return 0;
}