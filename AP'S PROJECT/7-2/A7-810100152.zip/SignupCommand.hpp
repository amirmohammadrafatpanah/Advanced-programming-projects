#ifndef __SIGNUP_COMMAND__
#define __SIGNUP_COMMAND__

#include "MemoryManager.hpp"
#include <iostream>
#include <map>
#include <vector>

class SignupCommand {
  std::string method;
  std::string username;
  std::string role;
  MemoryManager *memory;

public:
  SignupCommand(std::vector<std::string> args, const std::string &requestMethod,
                MemoryManager *memory);

  std::string getUsername();
  std::string getRole();

  void execute();

private:
  std::map<std::string, std::string> parseArgs(std::vector<std::string> args);
};

#endif