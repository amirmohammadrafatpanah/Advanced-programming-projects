#include "LocationManager.hpp"
#include "MemoryManager.hpp"
#include "RequestManager.hpp"
#include <cstdlib>
#include <iostream>

int main(int argc, char **argv)
{

  if (argc < 2)
  {
    std::cerr << "List of cities should be defined." << std::endl;
    exit(EXIT_FAILURE);
  }

  std::string locationsCsvFilePath = argv[1];

  LocationManager locationManager(locationsCsvFilePath);
  MemoryManager memory;

  std::string request;

  while (true)
  {
    std::getline(std::cin, request);
    if (request == "exit")
      break;

    RequestManager requestManager(request, &locationManager, &memory);

    requestManager.parseCommand();
  }

  return 0;
}