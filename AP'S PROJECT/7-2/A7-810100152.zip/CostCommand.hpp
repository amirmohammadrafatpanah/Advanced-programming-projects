#ifndef __COST_COMMAND__
#define __COST_COMMAND__

#include "MemoryManager.hpp"
#include "LocationManager.hpp"
#include <iostream>
#include <vector>

class CostCommand
{
  LocationManager *locations;
  MemoryManager *memory;
  std::string method;
  std::string username;
  std::vector<std::string> origin;
  std::vector<std::string> destination;
  bool in_hurry = false;

public:
  CostCommand(std::vector<std::string> args, const std::string &method,
              LocationManager *locations, MemoryManager *memory);

  std::string getUsername();
  std::vector<std::string> getOrigin();
  std::vector<std::string> getDestination();
  bool getInHurry();

  void execute();

private:
  std::map<std::string, std::string> parseArgs(std::vector<std::string> args);
};

#endif