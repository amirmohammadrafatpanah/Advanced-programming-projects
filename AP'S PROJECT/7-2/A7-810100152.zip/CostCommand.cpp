#include "CostCommand.hpp"
#include <cmath>
#include <iostream>
#include <iomanip>

std::map<std::string, std::string>
CostCommand::parseArgs(std::vector<std::string> args)
{
  std::map<std::string, std::string> tempData;

  for (std::size_t i = 0; i < args.size(); i += 2)
  {
    tempData[args[i]] = args[i + 1];
  }

  return tempData;
}

CostCommand::CostCommand(std::vector<std::string> args, const std::string &method, LocationManager *locations, MemoryManager *memory)
{
  auto parsedArgs = this->parseArgs(args);
  this->method = method;
  this->locations = locations;

  this->username = parsedArgs["username"];
  this->origin = this->locations->getLocationByName(parsedArgs["origin"]);
  this->destination = this->locations->getLocationByName(parsedArgs["destination"]);
  if (!parsedArgs["in_hurry"].empty())
  {
    this->in_hurry = parsedArgs["in_hurry"] == "yes" ? true : false;
  }

  this->memory = memory;
}

std::string CostCommand::getUsername()
{
  return this->username;
}

std::vector<std::string> CostCommand::getOrigin()
{
  return this->origin;
}

std::vector<std::string> CostCommand::getDestination()
{
  return this->destination;
}

bool CostCommand::getInHurry()
{
  return this->in_hurry;
}

void CostCommand::execute()
{
  if (this->username == "")
  {
    std::cerr << "Bad Request" << std::endl;
    return;
  }

  if (this->method != "GET")
  {
    std::cerr << "Bad Request" << std::endl;
    return;
  }

  if (this->origin.at(0).empty() || this->destination.at(0).empty())
  {
    std::cerr << "Not Found" << std::endl;
    return;
  }

  if (!this->memory->isUserExists(this->username))
  {
    std::cerr << "Not Found" << std::endl;
    return;
  }

  if (this->memory->getUserRole(this->username) != "passenger")
  {
    std::cerr << "Permission Denied" << std::endl;
    return;
  }

  if (this->memory->isUserOnTrip(this->username))
  {
    std::cerr << "Bad Request" << std::endl;
    return;
  }

  double lat1 = std::ceil(std::stod(this->origin.at(1)) * 100.0) / 100.0;
  double lng1 = std::ceil(std::stod(this->origin.at(2)) * 100.0) / 100.0;
  double lat2 = std::ceil(std::stod(this->destination.at(1)) * 100) / 100.0;
  double lng2 = std::ceil(std::stod(this->destination.at(2)) * 100.0) / 100.0;
  double traffic1 = std::ceil(std::stod(this->origin.at(3)) * 100.0) / 100.0;
  double traffic2 = std::ceil(std::stod(this->destination.at(3)) * 100.0) / 100.0;
  double inHurryCoefficient = this->in_hurry ? 1.2 : 1;

  double dist = 110.5 * std::sqrt(std::pow(lat2 - lat1, 2) + std::pow(lng2 - lng1, 2));
  double price = dist * (traffic1 + traffic2) * 10000 * inHurryCoefficient;
  price = std::ceil(price * 100.0) / 100.0;

  std::cout << std::fixed << std::setprecision(2) << price << std::endl;
}