#ifndef __ACCEPT_COMMAND__
#define __ACCEPT_COMMAND__

#include "MemoryManager.hpp"
#include <iostream>
#include <vector>

class AcceptCommand
{
  MemoryManager *memory;
  std::string method;
  std::string username;
  int id;

public:
  AcceptCommand(std::vector<std::string> args, const std::string &method,
                MemoryManager *memory);

  std::string getUsername();
  int getID();

  void execute();

private:
  std::map<std::string, std::string> parseArgs(std::vector<std::string> args);
};

#endif