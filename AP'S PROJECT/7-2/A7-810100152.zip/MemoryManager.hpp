#ifndef __MEMORY_MANAGER__
#define __MEMORY_MANAGER__

#include <iostream>
#include <map>
#include <vector>
#include <cmath>
#include <algorithm>

class MemoryManager
{
  std::map<std::string, std::pair<std::string, bool>> users;
  std::map<int, std::pair<std::vector<std::string>, std::string>> trips;
  std::map<std::string, std::vector<int>> driverTrips;
  int lastTripID = 0;

public:
  void addUser(const std::string &username, std::string role)
  {
    this->users.insert(std::make_pair(username, std::make_pair(role, false)));
  }

  void cancelTrip(int tripID)
  {
    auto tempTrip = this->trips[tripID];

    this->changeTripStatus(tripID, "canceled");
    this->changeUserTripStatus(tempTrip.first[0], false);
  }

  void finishTrip(int tripID)
  {
    auto tempTrip = this->trips[tripID];

    this->changeTripStatus(tripID, "finished");
    this->changeUserTripStatus(tempTrip.first[0], false);
  }

  void acceptTrip(int tripID, const std::string &username)
  {
    this->changeTripStatus(tripID, "traveling");
    this->driverTrips[username].push_back(tripID);
  }

  void changeUserTripStatus(const std::string &username, bool userTripStatus)
  {
    auto tempUser = this->users[username];
    this->users[username] = std::make_pair(tempUser.first, userTripStatus);
  }

  int addTrip(const std::string &username, const std::vector<std::string> &origin,
              const std::vector<std::string> &destination, const bool in_hurry)
  {
    double lat1 = std::stod(origin.at(1));
    double lng1 = std::stod(origin.at(2));
    double lat2 = std::stod(destination.at(1));
    double lng2 = std::stod(destination.at(2));
    double traffic1 = std::stod(origin.at(3));
    double traffic2 = std::stod(destination.at(3));
    double inHurryCoefficient = in_hurry ? 1.2 : 1;

    double dist = 110.5 * std::sqrt(std::pow(lat2 - lat1, 2) + std::pow(lng2 - lng1, 2));
    double price = dist * (traffic1 + traffic2) * 10000 * inHurryCoefficient;

    std::vector<std::string> tripInfo{username, origin.at(0), destination.at(0), std::to_string(std::ceil(price * 100.0) / 100.0)};
    this->trips.insert(std::make_pair(++this->lastTripID,
                                      std::make_pair(tripInfo, "waiting")));

    this->changeUserTripStatus(username, true);

    return this->lastTripID;
  }

  void changeTripStatus(int tripID, const std::string &status)
  {
    auto tempTrip = this->trips[tripID];
    this->trips[tripID] = std::make_pair(tempTrip.first, status);
  }

  std::pair<std::string, std::string> getUser(const std::string &username)
  {
    return std::make_pair(username, this->users[username].first);
  }

  std::vector<std::pair<int, std::pair<std::vector<std::string>, std::string>>>
  getTrips(const bool sort_by_cost)
  {
    std::vector<
        std::pair<int, std::pair<std::vector<std::string>, std::string>>>
        trips;
    for (auto trip : this->trips)
    {
      if (trip.second.second != "canceled")
        trips.push_back(std::make_pair(trip.first, trip.second));
    }

    if (sort_by_cost)
    {
      std::sort(trips.begin(), trips.end(), [](const std::pair<int, std::pair<std::vector<std::string>, std::string>> &trip1, const std::pair<int, std::pair<std::vector<std::string>, std::string>> &trip2)
                { return std::stod(trip1.second.first.at(3)) > std::stod(trip2.second.first.at(3)); });
    }

    return trips;
  }

  std::pair<int, std::pair<std::vector<std::string>, std::string>>
  getTrip(int tripID)
  {
    return std::make_pair(tripID, this->trips[tripID]);
  }

  bool isUserOnTrip(const std::string &username)
  {
    return this->users[username].second;
  }

  bool isUserExists(const std::string &username)
  {
    return this->users.count(username) == 1;
  }

  bool isUsernameDuplicate(const std::string &username)
  {
    return this->users.count(username) > 0;
  }

  bool isTripBelongsToUser(int tripID, const std::string &username)
  {
    auto tempUser = this->trips[tripID];

    return tempUser.first[0] == username;
  }

  bool isTripCancelable(int tripID)
  {
    auto tempTrip = this->trips[tripID];

    return tempTrip.second == "waiting";
  }

  bool isTripExists(int tripID) { return this->trips.count(tripID) > 0; }

  std::string getTripStatus(int tripID) { return this->trips[tripID].second; }

  std::string getUserRole(const std::string &username)
  {
    return this->users[username].first;
  }

  bool isDriverOnTrip(const std::string &username)
  {
    auto driverTrips = this->driverTrips[username];

    for (auto tripID : driverTrips)
    {
      if (this->trips[tripID].second == "traveling")
        return true;
    }

    return false;
  }

  bool isTripBelongsToDriver(int tripID, const std::string &username)
  {
    auto tempTrips = this->driverTrips[username];

    for (auto _tripID : tempTrips)
    {
      if (_tripID == tripID)
        return true;
    }

    return false;
  }
};

#endif