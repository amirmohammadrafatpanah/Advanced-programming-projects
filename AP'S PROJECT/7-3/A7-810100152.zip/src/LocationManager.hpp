#ifndef __LOCATION_MANAGER__
#define __LOCATION_MANAGER__

#include <fstream>
#include <iostream>
#include <vector>

class LocationManager
{
  std::string locationsCsvFilePath;
  std::ifstream *locationsCsvFileStream;
  std::string locationsCsvFileContent;
  std::vector<std::vector<std::string>> locations;

public:
  LocationManager(const std::string &locationsCsvFilePath);
  ~LocationManager();

  std::vector<std::string> getLocationByName(const std::string &locationName);
  std::vector<std::vector<std::string>> getLocations()
  {
    return this->locations;
  }

  bool isLocationExists(const std::string &locationName);

private:
  std::vector<std::vector<std::string>> parseLocations();
  std::string readFileAsString();
};

#endif