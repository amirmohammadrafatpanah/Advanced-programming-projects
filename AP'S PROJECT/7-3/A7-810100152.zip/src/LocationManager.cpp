#include "LocationManager.hpp"
#include <algorithm>
#include <fstream>
#include <iostream>
#include <sstream>
#include <vector>

LocationManager::LocationManager(const std::string &locationsCsvFilePath)
{
  this->locationsCsvFilePath = locationsCsvFilePath;
  this->locationsCsvFileStream = new std::ifstream(locationsCsvFilePath);

  if (!this->locationsCsvFileStream->is_open())
  {
    std::cerr << "Could not open locations csv file." << std::endl;
    exit(EXIT_FAILURE);
  }

  this->locationsCsvFileContent = this->readFileAsString();

  this->locations = this->parseLocations();
}

LocationManager::~LocationManager()
{
  this->locationsCsvFileStream->close();
  delete this->locationsCsvFileStream;
}

std::vector<std::string>
LocationManager::getLocationByName(const std::string &locationName)
{
  for (auto location : this->locations)
  {
    if (location[0] == locationName)
      return location;
  }

  return std::vector<std::string>{"", "", "", ""};
}

std::vector<std::vector<std::string>> LocationManager::parseLocations()
{
  std::istringstream tempCsvFileContantStream(this->locationsCsvFileContent);
  std::vector<std::string> tempCsvParsedResult;
  std::vector<std::vector<std::string>> locations;
  std::vector<std::string> tempLocation;
  std::string tempString;
  int index = 1;

  while (std::getline(tempCsvFileContantStream, tempString))
  {
    std::istringstream tempLineStream(tempString);
    while (std::getline(tempLineStream, tempString, ','))
    {
      tempCsvParsedResult.push_back(tempString);
    }
  }

  for (auto token : tempCsvParsedResult)
  {
    tempLocation.push_back(token);
    if (index % 4 == 0)
    {
      locations.push_back(tempLocation);
      tempLocation.clear();
    }
    index++;
  }

  return locations;
}

std::string LocationManager::readFileAsString()
{
  std::ostringstream fileContnentStream = std::ostringstream{};

  fileContnentStream << this->locationsCsvFileStream->rdbuf();

  return fileContnentStream.str();
}

bool LocationManager::isLocationExists(const std::string &locationName)
{
  for (auto locationDetail : this->locations)
  {
    if (locationName == locationDetail.at(0))
      return true;
  }

  return false;
}