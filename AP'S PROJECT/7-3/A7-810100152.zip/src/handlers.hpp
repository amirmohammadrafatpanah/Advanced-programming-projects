#ifndef _MY_HANDLERS_
#define _MY_HANDLERS_

#include "../server/server.hpp"
#include "LocationManager.hpp"
#include "memory.hpp"
#include <cstdlib> // for rand and srand
#include <ctime>   // for time
#include <iostream>

class AuthHandler : public RequestHandler
{
  MemoryManager *memory;

public:
  AuthHandler(MemoryManager *memory) : memory(memory){};
  Response *callback(Request *);
};

class SignupHandler : public RequestHandler
{
  MemoryManager *memory;

public:
  SignupHandler(MemoryManager *memory) : memory(memory){};
  Response *callback(Request *);
};

class LoginHandler : public RequestHandler
{
  MemoryManager *memory;

public:
  LoginHandler(MemoryManager *memory) : memory(memory){};
  Response *callback(Request *);
};

class LogoutHandler : public RequestHandler
{
public:
  Response *callback(Request *);
};

class HomeHandler : public TemplateHandler
{
  MemoryManager *memory;

public:
  HomeHandler(std::string, MemoryManager *memory);
  std::map<std::string, std::string> handle(Request *);
};

class RequestTripHandler : public TemplateHandler
{
  MemoryManager *memory;
  LocationManager *locations;

public:
  RequestTripHandler(std::string, MemoryManager *memory, LocationManager *locations);
  std::map<std::string, std::string> handle(Request *);
};

class CreateNewTripHandler : public RequestHandler
{
  MemoryManager *memory;
  LocationManager *locations;

public:
  CreateNewTripHandler(MemoryManager *memory, LocationManager *locations) : memory(memory), locations(locations){};
  Response *callback(Request *);
};

class RequestCostHandler : public RequestHandler
{
  LocationManager *locations;

public:
  RequestCostHandler(LocationManager *locations) : locations(locations){};
  Response *callback(Request *);
};

class AcceptTripHandler : public RequestHandler
{
  LocationManager *locations;
  MemoryManager *memory;

public:
  AcceptTripHandler(LocationManager *locations, MemoryManager *memory) : locations(locations), memory(memory){};
  Response *callback(Request *);
};

class CancelTripHandler : public RequestHandler
{
  LocationManager *locations;
  MemoryManager *memory;

public:
  CancelTripHandler(LocationManager *locations, MemoryManager *memory) : locations(locations), memory(memory){};
  Response *callback(Request *);
};

class FinishTripHandler : public RequestHandler
{
  LocationManager *locations;
  MemoryManager *memory;

public:
  FinishTripHandler(LocationManager *locations, MemoryManager *memory) : locations(locations), memory(memory){};
  Response *callback(Request *);
};

#endif