#include "handlers.hpp"
#include "server.hpp"
#include "LocationManager.hpp"
#include "memory.hpp"
#include <cstdlib> // for rand and srand
#include <ctime>   // for time
#include <iostream>

using namespace std;

int main(int argc, char **argv)
{

  LocationManager locations(argv[1]);
  MemoryManager memory;
  try
  {
    MyServer server(argc > 2 ? atoi(argv[2]) : 5000);
    server.get("/splash-image", new ShowImage("static/splash.jpeg"));
    server.get("/back-01", new ShowImage("static/back-01.jpeg"));
    server.get("/back-02", new ShowImage("static/back-02.jpeg"));
    server.get("/back-03", new ShowImage("static/back-03.jpeg"));
    server.get("/back-04", new ShowImage("static/back-04.jpeg"));
    server.get("/home-image", new ShowImage("static/home.svg"));
    server.get("/font", new ShowFile("static/Righteous-Regular.ttf", "font/ttf"));
    server.get("/", new AuthHandler(&memory));
    server.get("/home", new HomeHandler("template/home.html", &memory));
    server.get("/request-trip", new RequestTripHandler("template/request-trip.html", &memory, &locations));
    server.post("/request-trip", new CreateNewTripHandler(&memory, &locations));
    server.post("/get-request-cost", new RequestCostHandler(&locations));
    server.post("/accept-trip", new AcceptTripHandler(&locations, &memory));
    server.post("/cancel-trip", new CancelTripHandler(&locations, &memory));
    server.post("/finish-trip", new FinishTripHandler(&locations, &memory));
    server.get("/signup", new ShowPage("static/signup.html"));
    server.post("/signup", new SignupHandler(&memory));
    server.get("/login", new ShowPage("static/login.html"));
    server.post("/login", new LoginHandler(&memory));
    server.get("/logout", new LogoutHandler());
    server.run();
  }
  catch (Server::Exception e)
  {
    cerr << e.getMessage() << endl;
  }
}
