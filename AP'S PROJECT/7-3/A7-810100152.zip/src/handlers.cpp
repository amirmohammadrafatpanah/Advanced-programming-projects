#include "handlers.hpp"
#include <cmath>
#include <iostream>
#include <iomanip>

using namespace std;

Response *SignupHandler::callback(Request *req)
{

  if (req->getSessionId() != "")
  {
    Response *res_01 = Response::redirect("/");
    return res_01;
  }

  string username = req->getBodyParam("username");
  string role = req->getBodyParam("role");

  Response *res = Response::redirect("/");

  if (this->memory->isUserExists(username))
  {
    throw Server::Exception("User exists already.");
  }
  else
  {
    this->memory->addUser(username, role);
    res->setSessionId(username);
  }

  return res;
}

Response *AuthHandler::callback(Request *req)
{
  Response *res = Response::redirect("/home");

  if (req->getSessionId() == "")
  {
    delete res;
    res = Response::redirect("/login");
  }
  else if (!this->memory->isUserExists(req->getSessionId()))
  {
    res->setSessionId("");
  }

  return res;
}

Response *LogoutHandler::callback(Request *req)
{
  Response *res = Response::redirect("/login");
  res->setSessionId("");

  return res;
};

Response *LoginHandler::callback(Request *req)
{

  string username = req->getBodyParam("username");

  if (req->getSessionId() != "")
  {
    Response *res_01 = Response::redirect("/");
    return res_01;
  }
  else if (!this->memory->isUserExists(username))
  {
    throw Server::Exception("Username not exists. Signup first.");
  }

  Response *res = Response::redirect("/");
  res->setSessionId(username);

  return res;
};

HomeHandler::HomeHandler(string filePath, MemoryManager *memory) : TemplateHandler(filePath), memory(memory){};

map<string, string> HomeHandler::handle(Request *req)
{
  map<string, string> context;

  string username = req->getSessionId();

  if (!this->memory->isUserExists(username))
  {
    throw Server::Exception("Username not exists. Signup first.");
  }

  string role = this->memory->getUserRole(username);
  bool isUserOnTrip = this->memory->isUserOnTrip(username);

  string userRole = this->memory->getUserRole(username);
  bool sortByCost = req->getQueryParam("sort") == "cost" ? true : false;

  string tripsData("[");
  auto trips = this->memory->getTrips(sortByCost);

  if (role == "passenger")
  {
    tripsData.append("{");

    for (auto trip : trips)
    {
      if (trip.second.first.at(0) == username)
      {
        tripsData.append("\"id\":");
        tripsData.append(to_string(trip.first));
        tripsData.append(",");

        tripsData.append("\"status\":\"");
        tripsData.append(trip.second.second);
        tripsData.append("\",");

        tripsData.append("\"username\":\"");
        tripsData.append(trip.second.first.at(0));
        tripsData.append("\",");

        tripsData.append("\"origin\":\"");
        tripsData.append(trip.second.first.at(1));
        tripsData.append("\",");

        tripsData.append("\"destination\":\"");
        tripsData.append(trip.second.first.at(2));
        tripsData.append("\",");

        tripsData.append("\"cost\":\"");
        tripsData.append(trip.second.first.at(3));
        tripsData.append("\",");
      }
    }

    tripsData.append("}");
  }
  else
  {

    for (auto trip : trips)
    {
      tripsData.append("{");
      tripsData.append("\"id\":");
      tripsData.append(to_string(trip.first));
      tripsData.append(",");

      tripsData.append("\"status\":\"");
      tripsData.append(trip.second.second);
      tripsData.append("\",");

      tripsData.append("\"username\":\"");
      tripsData.append(trip.second.first.at(0));
      tripsData.append("\",");

      tripsData.append("\"origin\":\"");
      tripsData.append(trip.second.first.at(1));
      tripsData.append("\",");

      tripsData.append("\"destination\":\"");
      tripsData.append(trip.second.first.at(2));
      tripsData.append("\",");

      tripsData.append("\"cost\":\"");
      tripsData.append(trip.second.first.at(3));
      tripsData.append("\",");
      tripsData.append("},");
    }
  }

  tripsData.append("]");

  context["username"] = req->getSessionId();
  context["role"] = role;
  context["isUserOnTrip"] = isUserOnTrip ? "yes" : "no";
  context["trips"] = tripsData;

  return context;
};

RequestTripHandler::RequestTripHandler(string filePath, MemoryManager *memory, LocationManager *locations) : TemplateHandler(filePath), memory(memory), locations(locations) {}

map<string, string> RequestTripHandler::handle(Request *req)
{
  map<string, string> context;
  string username = req->getSessionId();

  if (!this->memory->isUserExists(username))
  {
    throw Server::Exception("Username not exists. Signup first.");
  }

  string role = this->memory->getUserRole(username);
  string locationsArray("[");

  for (auto location : this->locations->getLocations())
  {
    locationsArray.append("\"");
    locationsArray.append(location.at(0));
    locationsArray.append("\",");
  }

  locationsArray.append("]");

  context["locations"] = locationsArray;
  context["username"] = username;
  context["role"] = role;

  return context;
};

Response *CreateNewTripHandler::callback(Request *req)
{
  Response *res = Response::redirect("/home");

  string username = req->getSessionId();

  if (!this->memory->isUserExists(username))
  {
    throw Server::Exception("User is not exists.");
  }
  else if (this->memory->getUserRole(username) != "passenger")
  {
    throw Server::Exception("Requesting a trip is just for passengers.");
  }
  else if (this->memory->isUserOnTrip(username))
  {
    throw Server::Exception("This user is on trip already.");
  }

  string originLocation = req->getBodyParam("origin");
  string destinationLocation = req->getBodyParam("destination");
  bool inHurry = req->getBodyParam("in-hurry") == "on" ? true : false;

  auto origin = this->locations->getLocationByName(originLocation);
  auto destination = this->locations->getLocationByName(destinationLocation);

  this->memory->addTrip(username, origin, destination, inHurry);

  return res;
}

Response *RequestCostHandler::callback(Request *req)
{
  Response *res = new Response();

  string originLocation = req->getBodyParam("origin");
  string destinationLocation = req->getBodyParam("destination");
  bool inHurry = req->getBodyParam("in-hurry") == "yes" ? true : false;

  auto origin = this->locations->getLocationByName(originLocation);
  auto destination = this->locations->getLocationByName(destinationLocation);

  double lat1 = std::ceil(std::stod(origin.at(1)) * 100.0) / 100.0;
  double lng1 = std::ceil(std::stod(origin.at(2)) * 100.0) / 100.0;
  double lat2 = std::ceil(std::stod(destination.at(1)) * 100) / 100.0;
  double lng2 = std::ceil(std::stod(destination.at(2)) * 100.0) / 100.0;
  double traffic1 = std::ceil(std::stod(origin.at(3)) * 100.0) / 100.0;
  double traffic2 = std::ceil(std::stod(destination.at(3)) * 100.0) / 100.0;
  double inHurryCoefficient = inHurry ? 1.2 : 1;

  double dist = 110.5 * std::sqrt(std::pow(lat2 - lat1, 2) + std::pow(lng2 - lng1, 2));
  double price = dist * (traffic1 + traffic2) * 10000 * inHurryCoefficient;
  price = std::ceil(price * 100.0) / 100.0;

  res->setHeader("Content-Type", "application/json");

  string costJson("{\"cost\":");
  costJson.append(to_string(price));
  costJson.append("}");

  res->setBody(costJson);

  return res;
}

Response *AcceptTripHandler::callback(Request *req)
{
  int tripId = stoi(req->getBodyParam("id"));
  string username = req->getSessionId();

  if (!this->memory->isUserExists(username))
  {
    throw Server::Exception("User is not exists.");
  }
  else if (this->memory->getUserRole(username) != "driver")
  {
    throw Server::Exception("Only drivers can accept a trip.");
  }
  else if (this->memory->getTripStatus(tripId) != "waiting")
  {
    throw Server::Exception("Trip is not available for accepting.");
  }
  else if (!this->memory->isTripExists(tripId))
  {
    throw Server::Exception("Trip is not available for accepting.");
  }
  else if (this->memory->isDriverOnTrip(username))
  {
    throw Server::Exception("user is on trip already.");
  }

  this->memory->acceptTrip(tripId, username);

  Response *res = Response::redirect("/home");

  return res;
}

Response *CancelTripHandler::callback(Request *req)
{
  int tripId = stoi(req->getBodyParam("id"));
  string username = req->getSessionId();

  if (!this->memory->isUserExists(username))
  {
    throw Server::Exception("User is not exists.");
  }
  else if (this->memory->getUserRole(username) != "passenger")
  {
    throw Server::Exception("Only passengers can cancel a trip.");
  }
  else if (!this->memory->isTripExists(tripId))
  {
    throw Server::Exception("Trip is not available for canceling.");
  }
  else if (!this->memory->isTripBelongsToUser(tripId, username))
  {
    throw Server::Exception("This trip is not requested by this user.");
  }
  else if (this->memory->getTripStatus(tripId) == "canceled")
  {
    throw Server::Exception("This trip is canceled already.");
  }
  else if (!this->memory->isTripCancelable(tripId))
  {
    throw Server::Exception("This trip is not availabel for canceling.");
  }

  this->memory->cancelTrip(tripId);

  Response *res = Response::redirect("/home");

  return res;
}

Response *FinishTripHandler::callback(Request *req)
{
  int tripId = stoi(req->getBodyParam("id"));
  string username = req->getSessionId();

  if (!this->memory->isUserExists(username))
  {
    throw Server::Exception("User is not exists.");
  }
  else if (this->memory->getUserRole(username) != "driver")
  {
    throw Server::Exception("Only passengers can cancel a trip.");
  }
  else if (this->memory->getTripStatus(tripId) != "traveling")
  {
    throw Server::Exception("Trip is not available for finishing.");
  }
  else if (!this->memory->isTripExists(tripId))
  {
    throw Server::Exception("This trip is not available for finishing.");
  }
  else if (!this->memory->isTripBelongsToDriver(tripId, username))
  {
    throw Server::Exception("This trip does not belong to this user.");
  }

  this->memory->finishTrip(tripId);

  Response *res = Response::redirect("/home");

  return res;
}